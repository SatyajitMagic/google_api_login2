import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { GoogleOAuthProvider } from '@react-oauth/google';

const googleClientId = "1024295465397-04onebhvc0s9kl5ct3me9eliss4bgrs7.apps.googleusercontent.com"
ReactDOM.render(
  <GoogleOAuthProvider clientId={googleClientId}>
  <React.StrictMode>
    <App />
  </React.StrictMode>
  </GoogleOAuthProvider>,
  document.getElementById('root')
);