import Navbar from "./components/Navbar";
import "./app.css";
import Home from "./pages/Home";
import Post from "./pages/Post";
import Login from "./pages/Login";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";

const App = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {

   const getUser = () => {

      const header = { 
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin':"http://localhost:3000",
        'Access-Control-Allow-Headers':"*",
        'Access-Control-Allow-Credentials': true 
      }
      const requestOptions = {
        method: 'GET',
        headers: header
        //body: JSON.stringify({ title: 'React POST Request Example' })
      };
      fetch('http://localhost:5000/session/1',  requestOptions )
        .then(response => response.json())
        .then(data => console.log("--------data-----data-----",data))
        .catch(error => {
          //this.setState({ errorMessage: error.toString() });
          console.error('There was an error!', error);
      });;
    };
    getUser();
  }, []);

console.log("------user----",user);
  return (
    <BrowserRouter>
      <div>
        <Navbar user={user} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route
            path="/login"
            element={user ? <Navigate to="/" /> : <Login />}
          />
          <Route
            path="/post/:id"
            element={user ? <Post /> : <Navigate to="/login" />}
          />
        </Routes>
      </div>
    </BrowserRouter>
  );
};

export default App;
