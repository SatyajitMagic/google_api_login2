import Google from "../img/google.png";
import Facebook from "../img/facebook.png";
import Github from "../img/github.png";
import axios from 'axios';
//import GoogleLogin from 'react-google-login'
import { GoogleLogin,useGoogleOneTapLogin,useGoogleLogin  } from '@react-oauth/google';
const Login = () => {
  const google = () => {
    window.open("http://localhost:5000/auth/google_oauth2", "_self");
    
  };
  const loginGoogle = useGoogleLogin({
    //flow:'auth-code',
    onSuccess: async tokenResponse => {
      //alert()
      //console.log(234234324);
      console.log("-------tokenResponse--------",tokenResponse)
      const tokens = await axios.post('http://localhost:5000/auth/google_oauth2',{
        "code":tokenResponse.access_token
      })
      console.log("---------token----------",tokens);
      //getUser(tokenResponse);
    },
    onError:console.log('Login Failed')
  });
  const getUser = (tokenResponse) => {
    console.log("-------tokenResponse.access_token--------",tokenResponse.code)
     const header = {  'Content-Type': 'application/json',
                  'Access-Control-Allow-Headers':"*",
                  'Access-Control-Allow-Credentials': true,
                  'Access-Control-Allow-Origin':"http://localhost:3000"
                }
    const requestOptions = {
      method: 'POST',
      headers: header,
      body: JSON.stringify({"code":tokenResponse.code})
    };
  fetch('http://localhost:5000/auth/google_oauth2', requestOptions)
      .then(response => response.json())
      .then(data => this.setState({ postId: data.id }))
      .catch(error => {
        //this.setState({ errorMessage: error.toString() });
        console.error('There was an error!', error);
    });;
  };
  // const google = async () => {
  //   // console.log("------googleData-----",googleData);
  //    const res = await fetch("http://localhost:5000/auth/google_oauth2", {
  //       'method': 'GET',
  //       'mode': 'no-cors',
  //       "Content-Type":"application/json",
  //       "X-Requested-With":"XMLHttpRequest",
  //       'headers': {
  //         'Origin': 'localhost:3000',
  //         'Access-Control-Allow-Origin': '*',
  //       }
  //    })
  //    const data = await res.json()
  //    //store returned user somehow
  //  }

  // const github = () => {
  //   window.open("http://localhost:5000/auth/github", "_self");
  // };

  // const facebook = () => {
  //   window.open("http://localhost:5000/auth/facebook", "_self");
  // };

  return (
    <div className="login">
      <h1 className="loginTitle">Choose a Login Method</h1>
      <GoogleLogin
  onSuccess={credentialResponse => {
    console.log("--------------credentialResponse----------------",credentialResponse);
  }}
  onError={() => {
    console.log('Login Failed');
  }}
  useOneTap
/>
      <div className="wrapper">
        <div className="left">
          <div className="loginButton google" onClick={() => loginGoogle()}>
            <img src={Google} alt="" className="icon" />
            Google
          </div>
          
          <div className="loginButton google" onClick={google}>
            <img src={Google} alt="" className="icon" />
            GoogleGoogle
          </div>
          {/* <GoogleLogin
    clientId={googleClientId}
    buttonText="Log in with Google"
    onSuccess={google}
    onFailure={google}
    cookiePolicy={'single_host_origin'}
/> */}
           {/*<div className="loginButton facebook" onClick={facebook}>
            <img src={Facebook} alt="" className="icon" />
            Facebook
          </div>
          <div className="loginButton github" onClick={github}>
            <img src={Github} alt="" className="icon" />
            Github
          </div> */}
        </div>
        <div className="center">
          <div className="line" />
          <div className="or">OR</div>
        </div>
        <div className="right">
          <input type="text" placeholder="Username" />
          <input type="text" placeholder="Password" />
          <button className="submit">Login</button>
        </div>
      </div>
    </div>
  );
};

export default Login;
